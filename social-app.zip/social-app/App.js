import * as React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { View, TouchableOpacity, StyleSheet, Text } from 'react-native';
import { WebView } from 'react-native-webview';
import Icon from 'react-native-vector-icons/FontAwesome';
import 'react-native-gesture-handler';

const Stack = createStackNavigator();

const socialMediaLinks = {
  Facebook: 'https://www.facebook.com',
  Instagram: 'https://www.instagram.com',
  YouTube: 'https://www.youtube.com',
  X: 'https://www.twitter.com', // Changed Twitter to X
  Gmail: 'https://mail.google.com',
  Chrome: 'https://www.google.com/chrome/',
  WhatsApp: 'https://www.whatsapp.com',
  Telegram: 'https://telegram.com',
  Snapchat: 'https://www.snapchat.com',
  TikTok: 'https://www.tiktok.com',
};

const socialMediaIcons = {
  Facebook: { name: 'facebook', color: '#3b5998', iconSize: 35, iconColor: '#fff' },
  Instagram: { name: 'instagram', color: '#E4405F', iconSize: 40, iconColor: '#fff' },
  YouTube: { name: 'youtube-play', color: '#FF0000', iconSize: 30, iconColor: '#fff' },
  X: { name: 'times', color: '#000', iconSize: 35, iconColor: '#fff' }, // Changed Twitter icon to X
  Gmail: { name: 'envelope', color: '#D44638', iconSize: 35, iconColor: '#fff' },
  Chrome: { name: 'chrome', color: '#4285F4', iconSize: 35, iconColor: '#fff' },
  WhatsApp: { name: 'whatsapp', color: '#25D366', iconSize: 40, iconColor: '#fff' },
  Telegram: { name: 'send', color: '#0088cc', iconSize: 35, iconColor: '#fff' },
  Snapchat: { name: 'snapchat-ghost', color: '#FFFC00', iconSize: 40, iconColor: '#fff' },
  TikTok: { name: 'music', color: '#010101', iconSize: 35, iconColor: '#fff' },
};

function HomeScreen({ navigation }) {
  const sites = Object.keys(socialMediaLinks);
  const rows = [];
  for (let i = 0; i < sites.length; i += 3) {
    rows.push(sites.slice(i, i + 3));
  }

  return (
    <View style={styles.container}>
      {rows.map((row, index) => (
        <View style={styles.row} key={index}>
          {row.map((site) => (
            <TouchableOpacity
              key={site}
              style={[styles.button, { backgroundColor: socialMediaIcons[site].color }]}
              onPress={() => navigation.navigate('WebViewScreen', { url: socialMediaLinks[site] })}
            >
              <Icon
                name={socialMediaIcons[site].name}
                size={socialMediaIcons[site].iconSize}
                color={socialMediaIcons[site].iconColor}
                style={{ marginRight: 10 }}
              />
            </TouchableOpacity>
          ))}
        </View>
      ))}
      {/* Footer */}
      <View style={styles.footer}>
        <Text style={styles.footerText}>All rights reserved by M.YASIR</Text>
        <Text style={styles.footerText}>Contact on +92318601089</Text>
      </View>
    </View>
  );
}

function WebViewScreen({ route }) {
  const { url } = route.params;
  return <WebView source={{ uri: url }} style={{ flex: 1 }} />;
}

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="WebViewScreen" component={WebViewScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'space-between', // Space out the content and footer
    alignItems: 'center',
    backgroundColor: '#fff', // Set a default background color
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '100%',
    marginBottom: 20,
  },
  button: {
    padding: 20,
    borderRadius: 10,
    elevation: 5,
    justifyContent: 'center',
    alignItems: 'center',
  },
  footer: {
    padding: 10,
    backgroundColor: '#4CAF50', // Green background color
    width: '100%',
    alignItems: 'center',
  },
  footerText: {
    color: '#fff', // White text color for contrast
  },
});
